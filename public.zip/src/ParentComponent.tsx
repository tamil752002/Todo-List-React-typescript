import React, { useState } from 'react';
import { Input, Button, List, Checkbox } from 'antd';
import { CheckOutlined } from '@ant-design/icons';

interface Todo {
  id: number;
  text: string;
  completed: boolean;
}

const TodoApp: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputValue, setInputValue] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleAddTodo = () => {
    if (inputValue.trim() === '') return;
    const newTodo: Todo = {
      id: todos.length + 1,
      text: inputValue,
      completed: false,
    };
    setTodos([...todos, newTodo]);
    setInputValue('');
  };

  const handleToggleComplete = (todoId: number) => {
    const updatedTodos = todos.map(todo =>
      todo.id === todoId ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos);
  };

  const handleDeleteTodo = (todoId: number) => {
    const filteredTodos = todos.filter(todo => todo.id !== todoId);
    setTodos(filteredTodos);
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', marginTop: 50 }}>
      <h1>Todo App</h1>
      <Input
        placeholder="Enter a todo"
        value={inputValue}
        onChange={handleInputChange}
        style={{ marginBottom: 10 }}
      />
      <Button type="primary" onClick={handleAddTodo}>
        Add Todo
      </Button>
      <List
        style={{ marginTop: 20 }}
        dataSource={todos}
        renderItem={todo => (
          <List.Item
            actions={[
              <Checkbox
                key="completed"
                checked={todo.completed}
                onChange={() => handleToggleComplete(todo.id)}
              >
                <CheckOutlined style={{ color: todo.completed ? '#52c41a' : '#aaa' }} />
              </Checkbox>,
              <Button key="delete" type="text" danger onClick={() => handleDeleteTodo(todo.id)}>
                Delete
              </Button>,
            ]}
          >
            <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
              {todo.text}
            </span>
          </List.Item>
        )}
      />
    </div>
  );
};

export default TodoApp;
