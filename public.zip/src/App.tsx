import React from 'react';
import ParentComponent from "./ParentComponent";

function App() {

  let myname: string = "tamil";

  // To correct the type issue, ensure `myname` is always a string.
  // If you need to assign a number, consider using a union type:
  // let myname: string | number = "tamil";
  // myname = 10;

  return (
    <div className="App">
      {myname}
      <ParentComponent />
    </div>
  );
}

export default App;
